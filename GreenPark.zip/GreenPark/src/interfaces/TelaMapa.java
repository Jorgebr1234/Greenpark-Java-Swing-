/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package interfaces;

import java.awt.Image;
import javabeans.ResiduoBeans;
import javabeans.UsuarioBeans;
import javax.swing.ImageIcon;

/**
 *
 * @author jorge
 */
public class TelaMapa extends javax.swing.JFrame {
    
    UsuarioBeans busuario;
    ResiduoBeans beans;

    /**
     * Creates new form TelaMapa
     */
    public TelaMapa(UsuarioBeans usu, ResiduoBeans beans2) {
        initComponents();   
        
        busuario = usu;
        beans = beans2;
        
        if(beans.getTipo().equals("Papel")){
            if(busuario.getLocalidade().equals("Centro POA")){
                ImageIcon Img = new ImageIcon("src/images/PapelCentro.png");
                Image imgarrumada = Img.getImage().getScaledInstance(250, 150, Image.SCALE_SMOOTH);
                ImageIcon imgmenor = new ImageIcon(imgarrumada);
                jLabel2.setIcon(imgmenor);
            
            }
            else if(busuario.getLocalidade().equals("Leste POA")){
                ImageIcon Img = new ImageIcon("src/images/PapelLeste.png");
                Image imgarrumada = Img.getImage().getScaledInstance(250, 150, Image.SCALE_SMOOTH);
                ImageIcon imgmenor = new ImageIcon(imgarrumada);
                jLabel2.setIcon(imgmenor);
            }
            else if(busuario.getLocalidade().equals("Eldorado do Sul")){
                ImageIcon Img = new ImageIcon("src/images/PapelEldorado.png");
                Image imgarrumada = Img.getImage().getScaledInstance(250, 150, Image.SCALE_SMOOTH);
                ImageIcon imgmenor = new ImageIcon(imgarrumada);
                jLabel2.setIcon(imgmenor);
            
            }
            else{
                ImageIcon Img = new ImageIcon("src/images/PapelGuaiba.png");
                Image imgarrumada = Img.getImage().getScaledInstance(250, 150, Image.SCALE_SMOOTH);
                ImageIcon imgmenor = new ImageIcon(imgarrumada);
                jLabel2.setIcon(imgmenor);
            }
        }
        else if(beans.getTipo().equals("Plástico")){
             if(busuario.getLocalidade().equals("Centro POA")){
                ImageIcon Img = new ImageIcon("src/images/PlasticoCentro.png");
                Image imgarrumada = Img.getImage().getScaledInstance(250, 150, Image.SCALE_SMOOTH);
                ImageIcon imgmenor = new ImageIcon(imgarrumada);
                jLabel2.setIcon(imgmenor);
            
            }
            else if(busuario.getLocalidade().equals("Leste POA")){
                ImageIcon Img = new ImageIcon("src/images/PlasticoLeste.png");
                Image imgarrumada = Img.getImage().getScaledInstance(250, 150, Image.SCALE_SMOOTH);
                ImageIcon imgmenor = new ImageIcon(imgarrumada);
                jLabel2.setIcon(imgmenor);
                
            }
            else if(busuario.getLocalidade().equals("Eldorado do Sul")){
                ImageIcon Img = new ImageIcon("src/images/PlasticoEldorado.png");
                Image imgarrumada = Img.getImage().getScaledInstance(250, 150, Image.SCALE_SMOOTH);
                ImageIcon imgmenor = new ImageIcon(imgarrumada);
                jLabel2.setIcon(imgmenor);
            }
            else{
                ImageIcon Img = new ImageIcon("src/images/PlasticoGuaiba.png");
                Image imgarrumada = Img.getImage().getScaledInstance(250, 150, Image.SCALE_SMOOTH);
                ImageIcon imgmenor = new ImageIcon(imgarrumada);
                jLabel2.setIcon(imgmenor);
            }
        }
        else{
             if(busuario.getLocalidade().equals("Centro POA")){
                ImageIcon Img = new ImageIcon("src/images/VidroCentro.png");
                Image imgarrumada = Img.getImage().getScaledInstance(250, 150, Image.SCALE_SMOOTH);
                ImageIcon imgmenor = new ImageIcon(imgarrumada);
                jLabel2.setIcon(imgmenor);
            
            }
            else if(busuario.getLocalidade().equals("Leste POA")){
                ImageIcon Img = new ImageIcon("src/images/VidroLeste.png");
                Image imgarrumada = Img.getImage().getScaledInstance(250, 150, Image.SCALE_SMOOTH);
                ImageIcon imgmenor = new ImageIcon(imgarrumada);
                jLabel2.setIcon(imgmenor);
                
            }
            else if(busuario.getLocalidade().equals("Eldorado do Sul")){
                 ImageIcon Img = new ImageIcon("src/images/VidroEldorado.png");
                Image imgarrumada = Img.getImage().getScaledInstance(250, 150, Image.SCALE_SMOOTH);
                ImageIcon imgmenor = new ImageIcon(imgarrumada);
                jLabel2.setIcon(imgmenor);
            }
            else{
                ImageIcon Img = new ImageIcon("src/images/VidroGuaiba.png");
                Image imgarrumada = Img.getImage().getScaledInstance(250, 150, Image.SCALE_SMOOTH);
                ImageIcon imgmenor = new ImageIcon(imgarrumada);
                jLabel2.setIcon(imgmenor);
            }
        
        }
        
        
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        voltar = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        voltar.setText("Voltar");
        voltar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                voltarActionPerformed(evt);
            }
        });

        jLabel2.setText("");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(85, 85, 85)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(194, 194, 194)
                        .addComponent(jLabel1))
                    .addComponent(voltar, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(53, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 188, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(69, 69, 69))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(79, 79, 79)
                .addComponent(jLabel1)
                .addGap(22, 22, 22)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 173, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 107, Short.MAX_VALUE)
                .addComponent(voltar)
                .addGap(47, 47, 47))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void voltarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_voltarActionPerformed
        // TODO add your handling code here:
        this.dispose();
        new TelaPrincipal(busuario).setVisible(true);
    }//GEN-LAST:event_voltarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TelaMapa.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TelaMapa.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TelaMapa.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TelaMapa.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
             
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JButton voltar;
    // End of variables declaration//GEN-END:variables
}
